"""
Passenger WSGI file for cPanel deployment
This file is used when cPanel uses Passenger (Phusion Passenger) to run Python apps
"""
import sys
import os

# Get the directory where this file is located
current_dir = os.path.dirname(os.path.abspath(__file__))

# Add the backend directory to Python path
sys.path.insert(0, current_dir)

# Change to the backend directory
os.chdir(current_dir)

# Import the FastAPI app
from main import app

# For Passenger, we need to expose the application
application = app

